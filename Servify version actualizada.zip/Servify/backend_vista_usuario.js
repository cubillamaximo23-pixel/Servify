// Ingredientes específicos por cada momento del día
const categoryIngredients = {
    Desayuno: ['Huevo revuelto', 'Palta fresca', 'Queso crema', 'Miel pura', 'Frutos rojos', 'Semillas tostadas'],
    Almuerzo: ['Papas fritas', 'Queso Cheddar', 'Bacon crocante', 'Huevo frito', 'Cebolla caramelizada', 'Salsa especial'],
    Merienda: ['Dulce de leche artesanal', 'Crema chantilly', 'Frutos rojos', 'Queso extra', 'Jamón cocido'],
    Cena: ['Queso extra', 'Salsa de la casa', 'Papas rústicas', 'Aceitunas', 'Guarnición fresca'],
    Bebidas: [] // Bebidas no admiten ingredientes
};

// Menú estructurado exclusivamente en: Desayuno, Almuerzo, Merienda, Cena y Bebidas
const defaultMenuData = [
    {
        title: 'Desayuno',
        description: 'Opciones energéticas y frescas para comenzar el día.',
        items: [
            { id: 'des-tostadas', name: 'Tostadas con Palta y Huevo', description: 'Pan tostado de masa madre con palta fresca y huevo poché.', price: 4800, category: 'Desayuno' },
            { id: 'des-medialunas', name: 'Medialunas Rellenas', description: 'Medialunas de manteca calientes rellenas de jamón y queso.', price: 3400, category: 'Desayuno' },
            { id: 'des-bowl', name: 'Bowl de Yogur & Frutas', description: 'Yogur natural con granola artesanal, banana y miel.', price: 4200, category: 'Desayuno' }
        ]
    },
    {
        title: 'Almuerzo',
        description: 'Platos completos, sándwiches gourmet y opciones frescas para el mediodía.',
        items: [
            { id: 'alm-plato-ejecutivo', name: 'Plato del Día Ejecutivo', description: 'Carne braseada con papas doradas y guarnición de estación.', price: 8500, category: 'Almuerzo' },
            { id: 'alm-sandwich-gourmet', name: 'Sándwich Gourmet de Carne', description: 'Pan brioche tostado, carne seleccionada, queso y aderezos caseros.', price: 8200, category: 'Almuerzo' },
            { id: 'alm-wrap-pollo', name: 'Wrap Especial de Pollo', description: 'Tortilla de trigo rellena de pollo grillado, vegetales crocantes y aderezo.', price: 6900, category: 'Almuerzo' },
            { id: 'alm-bowl-fresco', name: 'Bowl Fresco de Estación', description: 'Mix de hojas verdes, tomates cherry, zanahoria, huevo y semillas.', price: 5800, category: 'Almuerzo' }
        ]
    },
    {
        title: 'Merienda',
        description: 'Tostados calientes, delicias dulces y opciones para la tarde.',
        items: [
            { id: 'mer-tostado', name: 'Tostado Mixto en Pan de Campo', description: 'Abundante queso fundido y jamón en pan dorado a la plancha.', price: 4600, category: 'Merienda' },
            { id: 'mer-waffle', name: 'Waffle Dulce con Toppings', description: 'Waffle tibio con dulce de leche artesanal, frutas y crema.', price: 4900, category: 'Merienda' },
            { id: 'mer-torta', name: 'Porción de Torta Artesanal', description: 'Variedad del día: Chocotorta, Lemon Pie o Carrot Cake casera.', price: 4300, category: 'Merienda' }
        ]
    },
    {
        title: 'Cena',
        description: 'Especialidades de la casa y platos nocturnos.',
        items: [
            { id: 'cen-plato-gourmet', name: 'Plato Gourmet de la Casa', description: 'Corte especial a punto con salsa suave y papas rústicas.', price: 9600, category: 'Cena' },
            { id: 'cen-horno-especial', name: 'Especialidad al Horno', description: 'Preparación artesanal al horno de barro con queso gratinado.', price: 9200, category: 'Cena' },
            { id: 'cen-sandwich-nocturno', name: 'Sándwich Premium Nocturno', description: 'Doble relleno de carne braseada, queso fundido y salsa especial.', price: 8800, category: 'Cena' },
            { id: 'cen-tabla-compartir', name: 'Tabla para Compartir', description: 'Selección de fiambres, quesos seleccionados y bocados calientes.', price: 11500, category: 'Cena' }
        ]
    },
    {
        title: 'Bebidas',
        description: 'Refrescos fríos, aguas y jugos naturales (sin ingredientes).',
        items: [
            { id: 'beb-coca', name: 'Coca Cola 350ml', description: 'Lata fría 350ml.', price: 1900, category: 'Bebidas' },
            { id: 'beb-agua', name: 'Agua Mineral 500ml', description: 'Con gas o sin gas.', price: 1300, category: 'Bebidas' },
            { id: 'beb-jugo', name: 'Jugo de Naranja Exprimido', description: 'Vaso 400ml exprimido natural en el momento.', price: 2500, category: 'Bebidas' },
            { id: 'beb-cerveza', name: 'Cerveza Artesanal 500ml', description: 'Golden Ale refrescante tirada.', price: 3200, category: 'Bebidas' }
        ]
    }
];

// Estado global de la aplicación y comandas por mesa
const tableOrders = {
    'Mesa 1': [],
    'Mesa 2': [],
    'Mesa 3': [],
    'Mesa 4': [],
    'Mesa 5': [],
    'Mesa 6': []
};

// Generador de turnos secuenciales
let currentTicketNumber = 14;

const orderState = {
    table: 'Mesa 1',
    ticketNumber: currentTicketNumber,
    queuePosition: 2, // Cantidad de clientes antes en la fila
    selfPickup: false,
    orderFinalized: false
};

// Formato de moneda en pesos
const formatPrice = amount => `$${Number(amount || 0).toLocaleString('es-AR')}`;

// Categorías válidas permitidas
const VALID_SECTIONS = ['Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Bebidas'];

// Obtener el menú combinando el base y los productos agregados desde admin
function getFullMenu() {
    const customAdminItems = localStorage.getItem('servifyAdminMenu');
    let adminProducts = [];
    if (customAdminItems) {
        try {
            const parsed = JSON.parse(customAdminItems);
            // Filtrar y eliminar cualquier producto que tenga categorías viejas (Pizzas, Hamburguesas, Ensaladas)
            adminProducts = parsed.filter(item => item && VALID_SECTIONS.includes(item.section));
            // Guardar la lista limpia en localStorage para que no vuelvan a aparecer
            localStorage.setItem('servifyAdminMenu', JSON.stringify(adminProducts));
        } catch (e) {
            adminProducts = [];
        }
    }

    // Copiar estructura base
    const menuClone = JSON.parse(JSON.stringify(defaultMenuData));

    if (Array.isArray(adminProducts) && adminProducts.length > 0) {
        adminProducts.forEach(prod => {
            const categoryName = prod.section;
            if (!VALID_SECTIONS.includes(categoryName)) return;

            let section = menuClone.find(s => s.title.toLowerCase() === categoryName.toLowerCase());
            if (section) {
                // Evitar duplicados por id
                if (!section.items.some(it => it.id === prod.id)) {
                    section.items.push({
                        id: prod.id || `custom-${Date.now()}-${Math.random()}`,
                        name: prod.name,
                        description: prod.description || 'Producto especial del menú.',
                        price: Number(prod.price) || 0,
                        category: categoryName
                    });
                }
            }
        });
    }

    // Asegurarse de que sólo se devuelvan las 5 secciones válidas
    return menuClone.filter(section => VALID_SECTIONS.includes(section.title));
}

// Obtener la comanda acumulada de la mesa actual
function getCurrentCart() {
    if (!tableOrders[orderState.table]) {
        tableOrders[orderState.table] = [];
    }
    return tableOrders[orderState.table];
}

// Renderizar el menú con pestañas desplegables y selector de ingredientes
function renderMenuSections() {
    const menuSections = document.getElementById('menuSections');
    if (!menuSections) return;
    menuSections.innerHTML = '';

    const menu = getFullMenu();

    menu.forEach((section, index) => {
        const details = document.createElement('details');
        details.className = 'menu-category-card';
        // Abrir la primera sección por defecto
        details.open = index === 0;

        const availableIngredients = categoryIngredients[section.title] || [];
        const isDrinkCategory = section.title.toLowerCase() === 'bebidas' || availableIngredients.length === 0;

        details.innerHTML = `
            <summary class="category-summary">
                <div class="category-info">
                    <span class="category-title">${section.title}</span>
                    <span class="category-count">${section.items.length} opciones</span>
                </div>
                <span class="category-arrow" aria-hidden="true">▾</span>
            </summary>
            <div class="category-items-grid"></div>
        `;

        const itemsContainer = details.querySelector('.category-items-grid');

        section.items.forEach(item => {
            const itemElement = document.createElement('article');
            itemElement.className = 'menu-item-row';
            itemElement.dataset.itemId = item.id;

            // Renderizar selector de ingredientes si corresponde
            let ingredientsHtml = '';
            if (!isDrinkCategory && availableIngredients.length > 0) {
                const chipsHtml = availableIngredients.map(ing => `
                    <button type="button" class="ingredient-chip" data-ingredient="${ing}">
                        <span class="chip-plus">+</span> ${ing}
                    </button>
                `).join('');

                ingredientsHtml = `
                    <div class="ingredients-section">
                        <span class="ingredients-label">Personalizar ingredientes:</span>
                        <div class="ingredients-chips">
                            ${chipsHtml}
                        </div>
                    </div>
                `;
            }

            itemElement.innerHTML = `
                <div class="item-main-details">
                    <div class="item-title-row">
                        <h4 class="item-title">${item.name}</h4>
                        <span class="item-price">${formatPrice(item.price)}</span>
                    </div>
                    <p class="item-description">${item.description}</p>
                    ${ingredientsHtml}
                </div>
                <div class="item-action-row">
                    <button type="button" class="btn btn-add" data-add-id="${item.id}">
                        Agregar al pedido
                    </button>
                </div>
            `;

            // Manejar selección interactiva de chips de ingredientes
            const chipButtons = itemElement.querySelectorAll('.ingredient-chip');
            chipButtons.forEach(chip => {
                chip.addEventListener('click', () => {
                    chip.classList.toggle('selected');
                    const icon = chip.querySelector('.chip-plus');
                    if (icon) {
                        icon.textContent = chip.classList.contains('selected') ? '✓' : '+';
                    }
                });
            });

            // Manejar clic en "Agregar al pedido"
            const addBtn = itemElement.querySelector('.btn-add');
            addBtn.addEventListener('click', () => {
                const selectedChips = itemElement.querySelectorAll('.ingredient-chip.selected');
                const selectedIngredients = Array.from(selectedChips).map(c => c.dataset.ingredient);
                
                addToCart(item, selectedIngredients);

                // Feedback visual en el botón
                addBtn.textContent = '¡Agregado!';
                addBtn.classList.add('added');
                setTimeout(() => {
                    addBtn.textContent = 'Agregar al pedido';
                    addBtn.classList.remove('added');
                }, 1000);
            });

            itemsContainer.appendChild(itemElement);
        });

        menuSections.appendChild(details);
    });
}

// Clave única para diferenciar productos con ingredientes personalizados
function buildItemKey(itemId, ingredients = []) {
    const sorted = [...ingredients].filter(Boolean).sort().join('|');
    return `${itemId}__${sorted}`;
}

// Agregar producto acumulándolo en la comanda de la mesa actual
function addToCart(item, selectedIngredients = []) {
    const cart = getCurrentCart();
    const key = buildItemKey(item.id, selectedIngredients);
    const existing = cart.find(entry => entry.key === key);

    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({
            key,
            id: item.id,
            name: item.name,
            description: item.description,
            price: Number(item.price) || 0,
            quantity: 1,
            ingredients: [...selectedIngredients],
            status: 'En preparación'
        });
    }

    // Si se agrega un nuevo producto después de haber finalizado, el pedido vuelve a acumular
    if (orderState.orderFinalized) {
        orderState.orderFinalized = false;
    }

    renderCart();
}

// Modificar cantidad: si baja a 0 con (-), elimina el producto directamente
function changeCartQuantity(itemKey, delta) {
    const cart = getCurrentCart();
    const index = cart.findIndex(entry => entry.key === itemKey);
    if (index === -1) return;

    const nextQty = cart[index].quantity + delta;

    if (nextQty <= 0) {
        // Eliminar producto si solo queda 1 y se presiona (-)
        cart.splice(index, 1);
    } else {
        cart[index].quantity = nextQty;
    }

    if (cart.length === 0) {
        orderState.orderFinalized = false;
    }

    renderCart();
}

// Eliminar directamente un producto del pedido
function removeCartItem(itemKey) {
    const cart = getCurrentCart();
    const index = cart.findIndex(entry => entry.key === itemKey);
    if (index !== -1) {
        cart.splice(index, 1);
    }

    if (cart.length === 0) {
        orderState.orderFinalized = false;
    }

    renderCart();
}

// Finalizar pedido: marca todos los productos como "Terminado" / "Listo" de un solo clic
function finalizeOrder() {
    const cart = getCurrentCart();
    if (cart.length === 0) return;

    cart.forEach(entry => {
        entry.status = 'Terminado';
    });

    orderState.orderFinalized = true;
    renderCart();
}

// Vaciar la comanda de la mesa actual
function clearCurrentOrder() {
    const cart = getCurrentCart();
    cart.length = 0;
    orderState.orderFinalized = false;
    renderCart();
}

// Renderizar la vista de comanda / pedido actual
function renderCart() {
    const cart = getCurrentCart();
    const cartList = document.getElementById('cartContent');
    const cartSummary = document.getElementById('cartSummary');
    const orderTicket = document.getElementById('orderTicket');
    const queueBadge = document.getElementById('queueBadge');
    const pickupAlert = document.getElementById('pickupAlert');
    const selfPickupCheck = document.getElementById('selfPickup');
    const mobileCartCount = document.getElementById('mobileCartCount');
    const mobileCartTotal = document.getElementById('mobileCartTotal');

    const totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

    // Actualizar indicador de pedido / turno
    if (orderTicket) {
        orderTicket.textContent = cart.length > 0 ? `Turno #${orderState.ticketNumber}` : 'Sin pedido activo';
    }

    // Actualizar clientes en fila
    if (queueBadge) {
        const waitingCustomers = cart.length > 0 ? orderState.queuePosition : 0;
        queueBadge.textContent = `${waitingCustomers} en fila`;
    }

    // Actualizar estado del checkbox de retiro en mostrador
    if (selfPickupCheck) {
        selfPickupCheck.checked = orderState.selfPickup;
    }

    // Actualizar indicador de "Listo para retirar en mostrador"
    if (pickupAlert) {
        if (orderState.selfPickup && orderState.orderFinalized && cart.length > 0) {
            pickupAlert.classList.remove('hidden');
            pickupAlert.innerHTML = `
                <div class="pickup-alert-box">
                    <span class="pickup-alert-icon">✓</span>
                    <div>
                        <strong>¡Tu pedido está listo para retirar!</strong>
                        <p>Puedes acercarte al mostrador con tu <strong>Turno #${orderState.ticketNumber}</strong>.</p>
                    </div>
                </div>
            `;
        } else {
            pickupAlert.classList.add('hidden');
            pickupAlert.innerHTML = '';
        }
    }

    // Actualizar barra móvil
    if (mobileCartCount) mobileCartCount.textContent = `${totalItems} items`;
    if (mobileCartTotal) mobileCartTotal.textContent = formatPrice(totalAmount);

    // Renderizar lista de productos
    if (!cartList) return;
    cartList.innerHTML = '';

    if (cart.length === 0) {
        cartList.innerHTML = `
            <div class="cart-empty-state">
                <p>No hay productos en el pedido de <strong>${orderState.table}</strong>.</p>
                <span>Selecciona productos del menú para comenzar.</span>
            </div>
        `;
    } else {
        cart.forEach(entry => {
            const itemCard = document.createElement('div');
            itemCard.className = 'cart-item-card';

            const ingredientsText = entry.ingredients.length > 0
                ? `<div class="cart-item-ingredients"><strong>Extras:</strong> ${entry.ingredients.join(', ')}</div>`
                : '';

            const isDone = entry.status === 'Terminado';

            itemCard.innerHTML = `
                <div class="cart-item-top">
                    <div class="cart-item-info">
                        <h5>${entry.name}</h5>
                        <span class="cart-item-unit-price">${formatPrice(entry.price)} c/u</span>
                    </div>
                    <span class="status-pill ${isDone ? 'status-ready' : 'status-prep'}">
                        ${isDone ? 'Listo' : 'En preparación'}
                    </span>
                </div>
                ${ingredientsText}
                <div class="cart-item-bottom">
                    <div class="quantity-controls">
                        <button type="button" class="btn-qty" data-action="dec" data-key="${entry.key}" title="Disminuir / Eliminar">-</button>
                        <span class="qty-number">${entry.quantity}</span>
                        <button type="button" class="btn-qty" data-action="inc" data-key="${entry.key}" title="Aumentar">+</button>
                    </div>
                    <div class="cart-item-subtotal">
                        <span>Subtotal:</span>
                        <strong>${formatPrice(entry.price * entry.quantity)}</strong>
                    </div>
                    <button type="button" class="btn-remove-line" data-action="del" data-key="${entry.key}" title="Quitar">✕</button>
                </div>
            `;

            cartList.appendChild(itemCard);
        });
    }

    // Renderizar resumen y acciones
    if (!cartSummary) return;
    cartSummary.innerHTML = `
        <div class="summary-details">
            <div class="summary-row">
                <span>Mesa seleccionada:</span>
                <strong>${orderState.table}</strong>
            </div>
            <div class="summary-row">
                <span>Total de productos:</span>
                <strong>${totalItems}</strong>
            </div>
            <div class="summary-row total-row">
                <span>Total a pagar:</span>
                <span class="total-amount">${formatPrice(totalAmount)}</span>
            </div>
        </div>
        <div class="summary-buttons">
            <button type="button" class="btn btn-finalize ${orderState.orderFinalized ? 'is-finalized' : ''}" id="btnFinalizeOrder" ${cart.length === 0 ? 'disabled' : ''}>
                ${orderState.orderFinalized ? '✓ Pedido finalizado' : 'Finalizar pedido'}
            </button>
            <button type="button" class="btn btn-clear" id="btnClearOrder" ${cart.length === 0 ? 'disabled' : ''}>
                Vaciar comanda
            </button>
        </div>
    `;

    // Asignar eventos de acciones de la comanda
    const btnFinalize = document.getElementById('btnFinalizeOrder');
    if (btnFinalize) {
        btnFinalize.addEventListener('click', finalizeOrder);
    }

    const btnClear = document.getElementById('btnClearOrder');
    if (btnClear) {
        btnClear.addEventListener('click', clearCurrentOrder);
    }

    // Eventos para botones de cantidad y eliminación
    cartList.querySelectorAll('[data-action]').forEach(button => {
        const action = button.dataset.action;
        const key = button.dataset.key;

        button.addEventListener('click', () => {
            if (action === 'inc') {
                changeCartQuantity(key, 1);
            } else if (action === 'dec') {
                changeCartQuantity(key, -1);
            } else if (action === 'del') {
                removeCartItem(key);
            }
        });
    });
}

// Inicialización de la aplicación
document.addEventListener('DOMContentLoaded', () => {
    const tableSelector = document.getElementById('tableSelector');
    const selfPickupCheck = document.getElementById('selfPickup');
    const mobileViewCartBtn = document.getElementById('mobileViewCartBtn');
    const cartAside = document.querySelector('.cart-aside');

    // Cambio de mesa: conserva la comanda acumulada de cada mesa
    if (tableSelector) {
        tableSelector.value = orderState.table;
        tableSelector.addEventListener('change', () => {
            orderState.table = tableSelector.value;
            renderCart();
        });
    }

    // Opción para buscar el pedido uno mismo
    if (selfPickupCheck) {
        selfPickupCheck.addEventListener('change', () => {
            orderState.selfPickup = selfPickupCheck.checked;
            renderCart();
        });
    }

    // Botón flotante móvil para abrir / desplazarse al pedido
    if (mobileViewCartBtn && cartAside) {
        mobileViewCartBtn.addEventListener('click', () => {
            cartAside.scrollIntoView({ behavior: 'smooth' });
        });
    }

    renderMenuSections();
    renderCart();
});