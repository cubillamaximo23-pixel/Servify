<?php
require_once __DIR__ . '/db_admin.php';

$adminUser = 'admin';
$adminPass = 'servify123';
$action = $_POST['action'] ?? '';
$requestMethod = $_SERVER['REQUEST_METHOD'] ?? '';
$loginError = '';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Manejo de Inicio y Cierre de Sesión
if ($requestMethod === 'POST') {
    if ($action === 'login') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === $adminUser && $password === $adminPass) {
            $_SESSION['admin_logged_in'] = true;
            header('Location: pagina_vista_admin.php');
            exit;
        }

        $loginError = 'Usuario o contraseña incorrectos.';
    }

    if ($action === 'logout') {
        session_destroy();
        header('Location: pagina_vista_admin.php');
        exit;
    }
}

$isLoggedIn = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'];

$products = [];

// Obtener productos si hay base de datos activa
if ($connection instanceof mysqli && $isLoggedIn && $dbStatus === 'conectado') {
    $productsResult = $connection->query('SELECT p.id, p.name, p.description, p.price, c.name AS category_name FROM products p JOIN categories c ON c.id = p.category_id ORDER BY p.id DESC');
    if ($productsResult) {
        $products = $productsResult->fetch_all(MYSQLI_ASSOC);
    }
}

// Cargar nuevo producto
if ($requestMethod === 'POST' && $action === 'add_product' && $isLoggedIn) {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = (float) ($_POST['price'] ?? 0);
    $categoryName = trim($_POST['section'] ?? '');

    if ($name !== '' && $price > 0 && $categoryName !== '' && $connection instanceof mysqli && $dbStatus === 'conectado') {
        $stmt = $connection->prepare('SELECT id FROM categories WHERE name = ?');
        $stmt->bind_param('s', $categoryName);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            $insertCategory = $connection->prepare('INSERT INTO categories (name) VALUES (?)');
            $insertCategory->bind_param('s', $categoryName);
            $insertCategory->execute();
            $categoryId = $insertCategory->insert_id;
        } else {
            $categoryId = $result->fetch_assoc()['id'];
        }

        $insertProduct = $connection->prepare('INSERT INTO products (category_id, name, description, price) VALUES (?, ?, ?, ?)');
        $insertProduct->bind_param('issd', $categoryId, $name, $description, $price);
        $insertProduct->execute();

        header('Location: pagina_vista_admin.php');
        exit;
    }
}

// Eliminar producto
if ($requestMethod === 'POST' && $action === 'delete_product' && $isLoggedIn) {
    $productId = (int) ($_POST['product_id'] ?? 0);
    if ($productId > 0 && $connection instanceof mysqli && $dbStatus === 'conectado') {
        $deleteStmt = $connection->prepare('DELETE FROM products WHERE id = ?');
        $deleteStmt->bind_param('i', $productId);
        $deleteStmt->execute();
        header('Location: pagina_vista_admin.php');
        exit;
    }
}
?>
