// Credenciales de acceso de Administrador
const ADMIN_CREDENTIALS = {
    username: 'admin',
    password: 'servify123'
};

// Menú inicial predeterminado para el panel de administración
const defaultAdminProducts = [
    { id: 'item-1', section: 'Desayuno', name: 'Tostadas con Palta y Huevo', description: 'Pan de masa madre tostado con palta y huevo poché.', price: 4800 },
    { id: 'item-2', section: 'Almuerzo', name: 'Plato del Día Ejecutivo', description: 'Carne braseada con papas doradas y guarnición.', price: 8500 },
    { id: 'item-3', section: 'Almuerzo', name: 'Sándwich Gourmet de Carne', description: 'Pan brioche tostado, carne seleccionada y queso.', price: 8200 },
    { id: 'item-4', section: 'Merienda', name: 'Tostado Mixto en Pan de Campo', description: 'Abundante queso y jamón en pan de campo dorado.', price: 4600 },
    { id: 'item-5', section: 'Merienda', name: 'Waffle Dulce con Toppings', description: 'Waffle tibio con dulce de leche y frutas.', price: 4900 },
    { id: 'item-6', section: 'Cena', name: 'Plato Gourmet de la Casa', description: 'Corte especial con salsa de la casa y papas rústicas.', price: 9600 },
    { id: 'item-7', section: 'Cena', name: 'Especialidad al Horno', description: 'Preparación artesanal al horno con queso gratinado.', price: 9200 },
    { id: 'item-8', section: 'Bebidas', name: 'Coca Cola 350ml', description: 'Lata fría 350ml.', price: 1900 },
    { id: 'item-9', section: 'Bebidas', name: 'Jugo de Naranja Exprimido', description: 'Vaso 400ml exprimido natural en el momento.', price: 2500 }
];

let adminProducts = [];

function loadAdminProducts() {
    const stored = localStorage.getItem('servifyAdminMenu');
    if (stored) {
        try {
            const parsed = JSON.parse(stored);
            // Filtrar y limpiar categorías obsoletas si existían
            adminProducts = parsed.filter(item => item && ['Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Bebidas'].includes(item.section));
            if (adminProducts.length === 0) {
                adminProducts = defaultAdminProducts.slice();
            }
        } catch (e) {
            adminProducts = defaultAdminProducts.slice();
        }
    } else {
        adminProducts = defaultAdminProducts.slice();
    }
    saveAdminProducts();
}

function saveAdminProducts() {
    localStorage.setItem('servifyAdminMenu', JSON.stringify(adminProducts));
}

// Control de Sesión y Vistas
function setAdminLoggedInState(isLoggedIn) {
    const loginSection = document.getElementById('loginSection');
    const dashboardSection = document.getElementById('dashboardSection');
    const logoutBtn = document.getElementById('adminLogoutBtn');
    const loginAlert = document.getElementById('loginAlert');

    if (isLoggedIn) {
        if (loginSection) loginSection.style.display = 'none';
        if (dashboardSection) dashboardSection.style.display = 'grid';
        if (logoutBtn) logoutBtn.style.display = 'inline-flex';
        if (loginAlert) loginAlert.style.display = 'none';
        renderAdminMenuTable();
    } else {
        if (loginSection) loginSection.style.display = 'flex';
        if (dashboardSection) dashboardSection.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'none';
    }
}

function handleLogin(event) {
    if (event) event.preventDefault();

    const userInput = document.getElementById('adminUsername');
    const passInput = document.getElementById('adminPassword');
    const loginAlert = document.getElementById('loginAlert');

    const user = userInput ? userInput.value.trim() : '';
    const pass = passInput ? passInput.value : '';

    if (user === ADMIN_CREDENTIALS.username && pass === ADMIN_CREDENTIALS.password) {
        sessionStorage.setItem('servify_admin_logged', 'true');
        setAdminLoggedInState(true);
        if (loginAlert) loginAlert.style.display = 'none';
        if (userInput) userInput.value = '';
        if (passInput) passInput.value = '';
    } else {
        if (loginAlert) {
            loginAlert.textContent = 'Usuario o contraseña incorrectos.';
            loginAlert.style.display = 'block';
        }
    }
}

function handleLogout() {
    sessionStorage.removeItem('servify_admin_logged');
    setAdminLoggedInState(false);
}

function renderAdminMenuTable() {
    const tbody = document.querySelector('#adminMenuTable tbody');
    if (!tbody) return;
    tbody.innerHTML = '';

    if (adminProducts.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `<td colspan="4" class="empty-table-msg">No hay productos en el menú. Agrega uno arriba.</td>`;
        tbody.appendChild(row);
        return;
    }

    adminProducts.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td data-label="Sección"><span class="badge-category">${item.section}</span></td>
            <td data-label="Producto">
                <strong class="prod-name">${item.name}</strong>
                ${item.description ? `<p class="prod-desc">${item.description}</p>` : ''}
            </td>
            <td data-label="Precio" class="prod-price">$${Number(item.price).toLocaleString('es-AR')}</td>
            <td data-label="Acción" class="td-action">
                <button class="btn btn-delete" type="button" data-delete-id="${item.id}" title="Eliminar producto">
                    Eliminar
                </button>
            </td>
        `;

        tbody.appendChild(row);
    });

    // Asignar eventos de eliminación
    tbody.querySelectorAll('[data-delete-id]').forEach(button => {
        button.addEventListener('click', () => {
            const id = button.dataset.deleteId;
            deleteAdminProduct(id);
        });
    });
}

function addAdminProduct(event) {
    if (event) event.preventDefault();

    const nameInput = document.getElementById('newProdName');
    const descInput = document.getElementById('newProdDesc');
    const priceInput = document.getElementById('newProdPrice');
    const sectionInput = document.getElementById('newProdSection');
    const alertBox = document.getElementById('adminAlert');

    const name = nameInput ? nameInput.value.trim() : '';
    const description = descInput ? descInput.value.trim() : '';
    const price = priceInput ? Number(priceInput.value) : 0;
    const section = sectionInput ? sectionInput.value : 'Almuerzo';

    if (!name || price <= 0) {
        if (alertBox) {
            alertBox.className = 'admin-alert error';
            alertBox.textContent = 'Por favor completa el nombre y un precio válido mayor a 0.';
            alertBox.style.display = 'block';
        }
        return;
    }

    const newProduct = {
        id: `prod-${Date.now()}`,
        section,
        name,
        description,
        price
    };

    adminProducts.unshift(newProduct);
    saveAdminProducts();
    renderAdminMenuTable();

    // Limpiar formulario
    if (nameInput) nameInput.value = '';
    if (descInput) descInput.value = '';
    if (priceInput) priceInput.value = '';
    if (sectionInput) sectionInput.value = 'Almuerzo';

    if (alertBox) {
        alertBox.className = 'admin-alert success';
        alertBox.textContent = `¡Producto "${name}" agregado correctamente al menú!`;
        alertBox.style.display = 'block';
        setTimeout(() => {
            alertBox.style.display = 'none';
        }, 3000);
    }
}

function deleteAdminProduct(productId) {
    adminProducts = adminProducts.filter(item => item.id !== productId);
    saveAdminProducts();
    renderAdminMenuTable();
}

document.addEventListener('DOMContentLoaded', () => {
    loadAdminProducts();

    // Verificar si ya estaba logueado
    const isLogged = sessionStorage.getItem('servify_admin_logged') === 'true';
    setAdminLoggedInState(isLogged);

    // Formulario de login
    const loginForm = document.getElementById('adminLoginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Botón de logout
    const logoutBtn = document.getElementById('adminLogoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }

    // Formulario de agregar producto
    const addForm = document.getElementById('addProductForm');
    if (addForm) {
        addForm.addEventListener('submit', addAdminProduct);
    }
});
