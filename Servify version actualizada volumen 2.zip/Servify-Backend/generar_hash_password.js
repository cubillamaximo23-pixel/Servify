// Uso: node generar_hash_password.js "tuContraseñaReal"
// Corré esto en tu propia computadora, nunca le mandes tu contraseña real a nadie.
// El resultado es lo único que va a la base de datos.

const bcrypt = require('bcrypt');

const password = process.argv[2];

if (!password) {
    console.log('Uso: node generar_hash_password.js "tuContraseña"');
    process.exit(1);
}

bcrypt.hash(password, 10).then(hash => {
    console.log('\nCopiá este hash en el insert de la tabla admin_users:\n');
    console.log(hash);
    console.log('');
});
