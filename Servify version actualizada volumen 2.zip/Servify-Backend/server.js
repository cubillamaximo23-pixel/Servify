// ============================================================
//  SERVIFY — Servidor Node.js + Express + Supabase
//  Archivo: server.js
//  Instrucciones de uso al final del archivo
// ============================================================

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;

app.use(cors());
app.use(express.json());

// service_role key, nunca la anon key acá
const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_KEY
);

function requireAdminAuth(req, res, next) {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

    if (!token) {
        return res.status(401).json({ error: 'No autorizado. Falta token de sesión.' });
    }

    try {
        req.admin = jwt.verify(token, JWT_SECRET);
        next();
    } catch (error) {
        return res.status(401).json({ error: 'Sesión inválida o vencida. Volvé a iniciar sesión.' });
    }
}

// ============================================================
//  LOGIN
// ============================================================

app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Usuario y contraseña son obligatorios.' });
    }

    const { data: admin, error } = await supabase
        .from('admin_users')
        .select('id, username, password_hash')
        .eq('username', username)
        .single();

    if (error || !admin) {
        return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
    }

    const passwordOk = await bcrypt.compare(password, admin.password_hash);

    if (!passwordOk) {
        return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
    }

    const token = jwt.sign(
        { id: admin.id, username: admin.username },
        JWT_SECRET,
        { expiresIn: '8h' }
    );

    res.json({ token, username: admin.username });
});

// GET /api/session — para que el panel verifique si el token sigue vivo al recargar la página
app.get('/api/session', requireAdminAuth, (req, res) => {
    res.json({ username: req.admin.username });
});

// ============================================================
//  MENÚ / PRODUCTOS
// ============================================================

app.get('/api/menu', async (req, res) => {
    const { data, error } = await supabase
        .from('productos')
        .select('*')
        .eq('disponible', true)
        .order('categoria', { ascending: true });

    if (error) {
        console.error('[GET /api/menu]', error.message);
        return res.status(500).json({ error: error.message });
    }

    const secciones = ['Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Bebidas'];
    const menuAgrupado = secciones.map(cat => ({
        title: cat,
        items: data.filter(p => p.categoria === cat)
    })).filter(s => s.items.length > 0);

    res.json(menuAgrupado);
});

// GET /api/productos — pública, la usa el panel admin para listar
app.get('/api/productos', async (req, res) => {
    const { data, error } = await supabase
        .from('productos')
        .select('*')
        .order('categoria', { ascending: true });

    if (error) {
        console.error('[GET /api/productos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});

app.post('/api/productos', requireAdminAuth, async (req, res) => {
    const { nombre, descripcion, precio, categoria, disponible } = req.body;

    if (!nombre || !precio || !categoria) {
        return res.status(400).json({ error: 'nombre, precio y categoria son obligatorios.' });
    }

    const secciones = ['Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Bebidas'];
    if (!secciones.includes(categoria)) {
        return res.status(400).json({ error: `Categoría inválida. Usar: ${secciones.join(', ')}` });
    }

    const { data, error } = await supabase
        .from('productos')
        .insert([{
            nombre,
            descripcion: descripcion || '',
            precio: Number(precio),
            categoria,
            disponible: disponible !== undefined ? disponible : true
        }])
        .select()
        .single();

    if (error) {
        console.error('[POST /api/productos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data);
});

app.put('/api/productos/:id', requireAdminAuth, async (req, res) => {
    const { id } = req.params;
    const campos = req.body;

    const { data, error } = await supabase
        .from('productos')
        .update(campos)
        .eq('id', id)
        .select()
        .single();

    if (error) {
        console.error('[PUT /api/productos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});

app.delete('/api/productos/:id', requireAdminAuth, async (req, res) => {
    const { id } = req.params;

    const { error } = await supabase
        .from('productos')
        .delete()
        .eq('id', id);

    if (error) {
        console.error('[DELETE /api/productos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json({ mensaje: 'Producto eliminado correctamente.' });
});


app.get('/api/ingredientes', async (req, res) => {
    const { categoria } = req.query;

    let query = supabase
        .from('ingredientes')
        .select('*')
        .order('nombre', { ascending: true });

    if (categoria) {
        query = query.eq('categoria', categoria);
    }

    const { data, error } = await query;

    if (error) {
        console.error('[GET /api/ingredientes]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});


app.post('/api/ingredientes', requireAdminAuth, async (req, res) => {
    const { nombre, precio, categoria } = req.body;

    if (!nombre || precio === undefined || !categoria) {
        return res.status(400).json({ error: 'nombre, precio y categoria son obligatorios.' });
    }

    const secciones = ['Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Bebidas'];
    if (!secciones.includes(categoria)) {
        return res.status(400).json({ error: `Categoría inválida. Usar: ${secciones.join(', ')}` });
    }

    const { data, error } = await supabase
        .from('ingredientes')
        .insert([{ nombre, precio: Number(precio), categoria }])
        .select()
        .single();

    if (error) {
        console.error('[POST /api/ingredientes]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data);
});


app.delete('/api/ingredientes/:id', requireAdminAuth, async (req, res) => {
    const { id } = req.params;

    const { error } = await supabase
        .from('ingredientes')
        .delete()
        .eq('id', id);

    if (error) {
        console.error('[DELETE /api/ingredientes]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json({ mensaje: 'Ingrediente eliminado correctamente.' });
});

app.post('/api/pedidos', async (req, res) => {
    const { mesa, items, retiro_mostrador } = req.body;

    if (!mesa || !items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Pedido incompleto. Se requiere mesa e items.' });
    }

    const total = items.reduce((sum, item) => {
        return sum + (Number(item.precio) * Number(item.cantidad));
    }, 0);

    const { data, error } = await supabase
        .from('pedidos')
        .insert([{
            mesa,
            items,
            total,
            retiro_mostrador: retiro_mostrador || false,
            estado: 'pendiente'
        }])
        .select()
        .single();

    if (error) {
        console.error('[POST /api/pedidos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json({
        mensaje: 'Pedido recibido',
        pedido_id: data.id,
        numero_turno: data.numero_turno || data.id.slice(0, 6).toUpperCase(),
        total: data.total
    });
});

app.get('/api/pedidos', requireAdminAuth, async (req, res) => {
    const { estado } = req.query;

    let query = supabase
        .from('pedidos')
        .select('*')
        .order('creado_at', { ascending: false });

    if (estado) {
        query = query.eq('estado', estado);
    }

    const { data, error } = await query;

    if (error) {
        console.error('[GET /api/pedidos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});

app.patch('/api/pedidos/:id/estado', requireAdminAuth, async (req, res) => {
    const { id } = req.params;
    const { estado } = req.body;

    const estadosValidos = ['pendiente', 'en_preparacion', 'listo', 'entregado'];
    if (!estadosValidos.includes(estado)) {
        return res.status(400).json({ error: `Estado inválido. Opciones: ${estadosValidos.join(', ')}` });
    }

    const { data, error } = await supabase
        .from('pedidos')
        .update({ estado })
        .eq('id', id)
        .select()
        .single();

    if (error) {
        console.error('[PATCH /api/pedidos/estado]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});


app.get('/api/status', async (req, res) => {
    const { error } = await supabase.from('productos').select('id').limit(1);
    res.json({
        servidor: 'activo',
        supabase: error ? 'error: ' + error.message : 'conectado',
        timestamp: new Date().toISOString()
    });
});

app.listen(PORT, () => {
    console.log(`\nServidor Servify corriendo en http://localhost:${PORT}`);
    console.log(`  Verificar estado:  http://localhost:${PORT}/api/status`);
    console.log(`  Ver menú:          http://localhost:${PORT}/api/menu`);
    console.log(`  Login admin:       POST http://localhost:${PORT}/api/login\n`);
});

