<?php
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servify - Portal de Acceso</title>
    <style>
        :root {
            --bg: #F4ECEC;
            --card: #ffffff;
            --text: #2C1E2D;
            --muted: #6b5a6c;
            --line: #e0cfc7;
            --primary: #2C1E2D;
            --accent: #49364A;
            --action: #F65351;
            --action-hover: #e03e3c;
            --warm: #EED3CB;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .portal-card {
            background: var(--card);
            border: 1px solid var(--line);
            border-radius: 20px;
            padding: 36px 32px;
            max-width: 480px;
            width: 100%;
            box-shadow: 0 8px 24px rgba(44, 30, 45, 0.08);
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .portal-header {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .portal-kicker {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--muted);
        }
        h1 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--action);
            letter-spacing: -0.02em;
        }
        p {
            color: var(--muted);
            font-size: 0.95rem;
            line-height: 1.5;
        }
        .nav-links {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 8px;
        }
        .btn-access {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: var(--bg);
            border: 1px solid var(--line);
            padding: 16px 20px;
            border-radius: 14px;
            text-decoration: none;
            color: var(--text);
            font-weight: 600;
            transition: all 0.2s ease;
        }
        .btn-access:hover {
            border-color: var(--action);
            background-color: rgba(246, 83, 81, 0.06);
            color: var(--action);
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(246, 83, 81, 0.12);
        }
        .btn-access strong {
            display: block;
            font-size: 1rem;
        }
        .btn-access span {
            font-size: 0.8rem;
            color: var(--muted);
            font-weight: 400;
        }
        .arrow-icon {
            font-size: 1.2rem;
            color: var(--action);
            transition: transform 0.2s ease;
        }
        .btn-access:hover .arrow-icon {
            transform: translateX(4px);
        }
    </style>
</head>
<body>
    <div class="portal-card">
        <div class="portal-header">
            <span class="portal-kicker">Plataforma Gastronómica</span>
            <h1>Servify</h1>
            <p>Bienvenido. Selecciona la vista a la que deseas acceder:</p>
        </div>

        <div class="nav-links">
            <a href="pagina_vista_usuario.php" class="btn-access">
                <div>
                    <strong>Vista de Cliente / Menú Digital</strong>
                    <span>Carta interactiva, selección de ingredientes y comanda</span>
                </div>
                <span class="arrow-icon">→</span>
            </a>

            <a href="Vista%20de%20admin/pagina_vista_admin.php" class="btn-access">
                <div>
                    <strong>Panel de Administrador</strong>
                    <span>Carga de productos y administración del menú</span>
                </div>
                <span class="arrow-icon">→</span>
            </a>
        </div>
    </div>
</body>
</html>
