

const API_URL = 'http://localhost:3000/api';


const categoryIngredients = {
    Desayuno:  ['Huevo revuelto', 'Palta fresca', 'Queso crema', 'Miel pura', 'Frutos rojos', 'Semillas tostadas'],
    Almuerzo:  ['Papas fritas', 'Queso Cheddar', 'Bacon crocante', 'Huevo frito', 'Cebolla caramelizada', 'Salsa especial'],
    Merienda:  ['Dulce de leche artesanal', 'Crema chantilly', 'Frutos rojos', 'Queso extra', 'Jamón cocido'],
    Cena:      ['Queso extra', 'Salsa de la casa', 'Papas rústicas', 'Aceitunas', 'Guarnición fresca'],
    Bebidas:   []
};

const VALID_SECTIONS = ['Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Bebidas'];


const tableOrders = {
    'Mesa 1': [], 'Mesa 2': [], 'Mesa 3': [],
    'Mesa 4': [], 'Mesa 5': [], 'Mesa 6': []
};

let currentTicketNumber = 14;

const orderState = {
    table:          'Mesa 1',
    ticketNumber:   currentTicketNumber,
    queuePosition:  2,
    selfPickup:     false,
    orderFinalized: false
};

const formatPrice = amount => `$${Number(amount || 0).toLocaleString('es-AR')}`;

async function fetchMenuDesdeAPI() {
    try {
        const response = await fetch(`${API_URL}/menu`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const menuAgrupado = await response.json();

       
        return menuAgrupado.map(seccion => ({
            title: seccion.title,
            description: '',
            items: seccion.items.map(p => ({
                id:          p.id,
                name:        p.nombre,
                description: p.descripcion || '',
                price:       Number(p.precio),
                category:    p.categoria
            }))
        }));

    } catch (err) {
        console.error('Error al cargar el menú desde la API:', err);
       
        const menuSection = document.getElementById('menuSections');
        if (menuSection) {
            menuSection.innerHTML = `
                <div style="padding:24px;text-align:center;color:#b91c1c;background:#fef2f2;border-radius:12px;margin:16px 0;">
                    <strong>No se pudo conectar con el servidor.</strong><br>
                    <span style="font-size:0.85rem">Asegurate de que Node.js esté corriendo en http://localhost:3000</span>
                </div>`;
        }
        return [];
    }
}


function getCurrentCart() {
    if (!tableOrders[orderState.table]) {
        tableOrders[orderState.table] = [];
    }
    return tableOrders[orderState.table];
}


async function renderMenuSections() {
    const menuSections = document.getElementById('menuSections');
    if (!menuSections) return;

   
    menuSections.innerHTML = `
        <div style="padding:24px;text-align:center;color:#64748b;">
            Cargando menú...
        </div>`;

    const menu = await fetchMenuDesdeAPI();
    menuSections.innerHTML = '';

    if (!menu.length) return; 

    menu.forEach((section, index) => {
        const details = document.createElement('details');
        details.className = 'menu-category-card';
        details.open = index === 0;

        const availableIngredients = categoryIngredients[section.title] || [];
        const isDrinkCategory = section.title.toLowerCase() === 'bebidas' || availableIngredients.length === 0;

        details.innerHTML = `
            <summary class="category-summary">
                <div class="category-info">
                    <span class="category-title">${section.title}</span>
                    <span class="category-count">${section.items.length} opciones</span>
                </div>
                <span class="category-arrow" aria-hidden="true">▾</span>
            </summary>
            <div class="category-items-grid"></div>
        `;

        const itemsContainer = details.querySelector('.category-items-grid');

        section.items.forEach(item => {
            const itemElement = document.createElement('article');
            itemElement.className = 'menu-item-row';
            itemElement.dataset.itemId = item.id;

            let ingredientsHtml = '';
            if (!isDrinkCategory && availableIngredients.length > 0) {
                const chipsHtml = availableIngredients.map(ing => `
                    <button type="button" class="ingredient-chip" data-ingredient="${ing}">
                        <span class="chip-plus">+</span> ${ing}
                    </button>
                `).join('');
                ingredientsHtml = `
                    <div class="ingredients-section">
                        <span class="ingredients-label">Personalizar ingredientes:</span>
                        <div class="ingredients-chips">${chipsHtml}</div>
                    </div>`;
            }

            itemElement.innerHTML = `
                <div class="item-main-details">
                    <div class="item-title-row">
                        <h4 class="item-title">${item.name}</h4>
                        <span class="item-price">${formatPrice(item.price)}</span>
                    </div>
                    <p class="item-description">${item.description}</p>
                    ${ingredientsHtml}
                </div>
                <div class="item-action-row">
                    <button type="button" class="btn btn-add" data-add-id="${item.id}">
                        Agregar al pedido
                    </button>
                </div>
            `;

            const chipButtons = itemElement.querySelectorAll('.ingredient-chip');
            chipButtons.forEach(chip => {
                chip.addEventListener('click', () => {
                    chip.classList.toggle('selected');
                    const icon = chip.querySelector('.chip-plus');
                    if (icon) icon.textContent = chip.classList.contains('selected') ? '✓' : '+';
                });
            });

            const addBtn = itemElement.querySelector('.btn-add');
            addBtn.addEventListener('click', () => {
                const selectedIngredients = Array.from(
                    itemElement.querySelectorAll('.ingredient-chip.selected')
                ).map(c => c.dataset.ingredient);

                addToCart(item, selectedIngredients);

                addBtn.textContent = '¡Agregado!';
                addBtn.classList.add('added');
                setTimeout(() => {
                    addBtn.textContent = 'Agregar al pedido';
                    addBtn.classList.remove('added');
                }, 1000);
            });

            itemsContainer.appendChild(itemElement);
        });

        menuSections.appendChild(details);
    });
}


function buildItemKey(itemId, ingredients = []) {
    return `${itemId}__${[...ingredients].filter(Boolean).sort().join('|')}`;
}

function addToCart(item, selectedIngredients = []) {
    const cart = getCurrentCart();
    const key  = buildItemKey(item.id, selectedIngredients);
    const existing = cart.find(e => e.key === key);

    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({
            key,
            id:          item.id,
            name:        item.name,
            description: item.description,
            price:       Number(item.price) || 0,
            cantidad:    1,
            quantity:    1,
            ingredients: [...selectedIngredients],
            status:      'En preparación'
        });
    }

    if (orderState.orderFinalized) orderState.orderFinalized = false;
    renderCart();
}

function changeCartQuantity(itemKey, delta) {
    const cart  = getCurrentCart();
    const index = cart.findIndex(e => e.key === itemKey);
    if (index === -1) return;

    const nextQty = cart[index].quantity + delta;
    if (nextQty <= 0) {
        cart.splice(index, 1);
    } else {
        cart[index].quantity = nextQty;
        cart[index].cantidad = nextQty;
    }

    if (cart.length === 0) orderState.orderFinalized = false;
    renderCart();
}

function removeCartItem(itemKey) {
    const cart  = getCurrentCart();
    const index = cart.findIndex(e => e.key === itemKey);
    if (index !== -1) cart.splice(index, 1);
    if (cart.length === 0) orderState.orderFinalized = false;
    renderCart();
}

function clearCurrentOrder() {
    getCurrentCart().length = 0;
    orderState.orderFinalized = false;
    renderCart();
}


async function finalizeOrder() {
    const cart = getCurrentCart();
    if (cart.length === 0) return;

    const btnFinalize = document.getElementById('btnFinalizeOrder');
    if (btnFinalize) {
        btnFinalize.disabled    = true;
        btnFinalize.textContent = 'Enviando pedido...';
    }

    try {
        const response = await fetch(`${API_URL}/pedidos`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                mesa:             orderState.table,
                retiro_mostrador: orderState.selfPickup,
                items: cart.map(item => ({
                    id:          item.id,
                    nombre:      item.name,
                    precio:      item.price,
                    cantidad:    item.quantity,
                    ingredientes: item.ingredients || []
                }))
            })
        });

        const resultado = await response.json();

        if (!response.ok) {
            throw new Error(resultado.error || 'Error al enviar el pedido');
        }

        // Pedido enviado con éxito
        cart.forEach(e => e.status = 'Terminado');
        orderState.orderFinalized = true;
        orderState.ticketNumber   = resultado.numero_turno || orderState.ticketNumber;
        renderCart();

        console.log('✅ Pedido guardado en Supabase. ID:', resultado.pedido_id);

    } catch (err) {
        console.error('Error al finalizar pedido:', err);
        alert(`No se pudo enviar el pedido:\n${err.message}\n\nVerificá que el servidor Node.js esté corriendo.`);
        if (btnFinalize) {
            btnFinalize.disabled    = false;
            btnFinalize.textContent = 'Finalizar pedido';
        }
    }
}


function renderCart() {
    const cart             = getCurrentCart();
    const cartList         = document.getElementById('cartContent');
    const cartSummary      = document.getElementById('cartSummary');
    const orderTicket      = document.getElementById('orderTicket');
    const queueBadge       = document.getElementById('queueBadge');
    const pickupAlert      = document.getElementById('pickupAlert');
    const selfPickupCheck  = document.getElementById('selfPickup');
    const mobileCartCount  = document.getElementById('mobileCartCount');
    const mobileCartTotal  = document.getElementById('mobileCartTotal');

    const totalAmount = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
    const totalItems  = cart.reduce((sum, i) => sum + i.quantity, 0);

    if (orderTicket)     orderTicket.textContent    = cart.length > 0 ? `Turno #${orderState.ticketNumber}` : 'Sin pedido activo';
    if (queueBadge)      queueBadge.textContent     = `${cart.length > 0 ? orderState.queuePosition : 0} en fila`;
    if (selfPickupCheck) selfPickupCheck.checked    = orderState.selfPickup;
    if (mobileCartCount) mobileCartCount.textContent = `${totalItems} items`;
    if (mobileCartTotal) mobileCartTotal.textContent = formatPrice(totalAmount);

    if (pickupAlert) {
        if (orderState.selfPickup && orderState.orderFinalized && cart.length > 0) {
            pickupAlert.classList.remove('hidden');
            pickupAlert.innerHTML = `
                <div class="pickup-alert-box">
                    <span class="pickup-alert-icon">✓</span>
                    <div>
                        <strong>¡Tu pedido fue enviado al local!</strong>
                        <p>Turno <strong>#${orderState.ticketNumber}</strong> — podés acercarte al mostrador.</p>
                    </div>
                </div>`;
        } else {
            pickupAlert.classList.add('hidden');
            pickupAlert.innerHTML = '';
        }
    }

    if (!cartList) return;
    cartList.innerHTML = '';

    if (cart.length === 0) {
        cartList.innerHTML = `
            <div class="cart-empty-state">
                <p>No hay productos en el pedido de <strong>${orderState.table}</strong>.</p>
                <span>Seleccioná productos del menú para comenzar.</span>
            </div>`;
    } else {
        cart.forEach(entry => {
            const itemCard = document.createElement('div');
            itemCard.className = 'cart-item-card';
            const ingText  = entry.ingredients.length > 0
                ? `<div class="cart-item-ingredients"><strong>Extras:</strong> ${entry.ingredients.join(', ')}</div>`
                : '';
            const isDone = entry.status === 'Terminado';

            itemCard.innerHTML = `
                <div class="cart-item-top">
                    <div class="cart-item-info">
                        <h5>${entry.name}</h5>
                        <span class="cart-item-unit-price">${formatPrice(entry.price)} c/u</span>
                    </div>
                    <span class="status-pill ${isDone ? 'status-ready' : 'status-prep'}">
                        ${isDone ? 'Enviado ✓' : 'En pedido'}
                    </span>
                </div>
                ${ingText}
                <div class="cart-item-bottom">
                    <div class="quantity-controls">
                        <button type="button" class="btn-qty" data-action="dec" data-key="${entry.key}">-</button>
                        <span class="qty-number">${entry.quantity}</span>
                        <button type="button" class="btn-qty" data-action="inc" data-key="${entry.key}">+</button>
                    </div>
                    <div class="cart-item-subtotal">
                        <span>Subtotal:</span>
                        <strong>${formatPrice(entry.price * entry.quantity)}</strong>
                    </div>
                    <button type="button" class="btn-remove-line" data-action="del" data-key="${entry.key}">✕</button>
                </div>`;
            cartList.appendChild(itemCard);
        });
    }

    if (!cartSummary) return;
    cartSummary.innerHTML = `
        <div class="summary-details">
            <div class="summary-row">
                <span>Mesa seleccionada:</span>
                <strong>${orderState.table}</strong>
            </div>
            <div class="summary-row">
                <span>Total de productos:</span>
                <strong>${totalItems}</strong>
            </div>
            <div class="summary-row total-row">
                <span>Total a pagar:</span>
                <span class="total-amount">${formatPrice(totalAmount)}</span>
            </div>
        </div>
        <div class="summary-buttons">
            <button type="button" class="btn btn-finalize ${orderState.orderFinalized ? 'is-finalized' : ''}"
                id="btnFinalizeOrder" ${cart.length === 0 ? 'disabled' : ''}>
                ${orderState.orderFinalized ? '✓ Pedido enviado' : 'Finalizar pedido'}
            </button>
            <button type="button" class="btn btn-clear" id="btnClearOrder" ${cart.length === 0 ? 'disabled' : ''}>
                Vaciar comanda
            </button>
        </div>`;

    document.getElementById('btnFinalizeOrder')?.addEventListener('click', finalizeOrder);
    document.getElementById('btnClearOrder')?.addEventListener('click', clearCurrentOrder);

    cartList.querySelectorAll('[data-action]').forEach(btn => {
        btn.addEventListener('click', () => {
            const { action, key } = btn.dataset;
            if (action === 'inc') changeCartQuantity(key,  1);
            if (action === 'dec') changeCartQuantity(key, -1);
            if (action === 'del') removeCartItem(key);
        });
    });
}


document.addEventListener('DOMContentLoaded', () => {
    const tableSelector    = document.getElementById('tableSelector');
    const selfPickupCheck  = document.getElementById('selfPickup');
    const mobileViewCartBtn = document.getElementById('mobileViewCartBtn');
    const cartAside        = document.querySelector('.cart-aside');

    if (tableSelector) {
        tableSelector.value = orderState.table;
        tableSelector.addEventListener('change', () => {
            orderState.table = tableSelector.value;
            renderCart();
        });
    }

    if (selfPickupCheck) {
        selfPickupCheck.addEventListener('change', () => {
            orderState.selfPickup = selfPickupCheck.checked;
            renderCart();
        });
    }

    if (mobileViewCartBtn && cartAside) {
        mobileViewCartBtn.addEventListener('click', () => {
            cartAside.scrollIntoView({ behavior: 'smooth' });
        });
    }

    
    renderMenuSections();
    renderCart();
});
