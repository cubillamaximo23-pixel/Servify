 
const API_URL = 'http://localhost:3000/api';
 
let adminProducts = [];
 

 
function getToken() {
    return sessionStorage.getItem('servify_admin_token');
}
 
function setAdminLoggedInState(isLoggedIn) {
    const loginSection = document.getElementById('loginSection');
    const dashboardSection = document.getElementById('dashboardSection');
    const logoutBtn = document.getElementById('adminLogoutBtn');
    const loginAlert = document.getElementById('loginAlert');
 
    if (isLoggedIn) {
        if (loginSection) loginSection.style.display = 'none';
        if (dashboardSection) dashboardSection.style.display = 'grid';
        if (logoutBtn) logoutBtn.style.display = 'inline-flex';
        if (loginAlert) loginAlert.style.display = 'none';
        loadAdminProducts();
    } else {
        if (loginSection) loginSection.style.display = 'flex';
        if (dashboardSection) dashboardSection.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'none';
        sessionStorage.removeItem('servify_admin_logged');
        sessionStorage.removeItem('servify_admin_token');
    }
}
 
async function checkExistingSession() {
    const token = getToken();
    if (!token) {
        setAdminLoggedInState(false);
        return;
    }
    try {
        const response = await fetch(`${API_URL}/session`, {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        setAdminLoggedInState(response.ok);
    } catch (error) {
        setAdminLoggedInState(false);
    }
}
 
async function handleLogin(event) {
    if (event) event.preventDefault();
 
    const userInput = document.getElementById('adminUsername');
    const passInput = document.getElementById('adminPassword');
    const loginAlert = document.getElementById('loginAlert');
    const submitBtn = document.getElementById('loginSubmitBtn');
 
    const username = userInput ? userInput.value.trim() : '';
    const password = passInput ? passInput.value : '';
 
    if (!username || !password) {
        if (loginAlert) {
            loginAlert.textContent = 'Completa usuario y contraseña.';
            loginAlert.style.display = 'block';
        }
        return;
    }
 
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Verificando...';
    }
 
    try {
        const response = await fetch(`${API_URL}/admin/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
 
        const data = await response.json();
 
        if (response.ok && data.token) {
            sessionStorage.setItem('servify_admin_logged', 'true');
            sessionStorage.setItem('servify_admin_token', data.token);
            setAdminLoggedInState(true);
            if (loginAlert) loginAlert.style.display = 'none';
            if (userInput) userInput.value = '';
            if (passInput) passInput.value = '';
        } else {
            if (loginAlert) {
                loginAlert.textContent = data.error || 'Usuario o contraseña incorrectos.';
                loginAlert.style.display = 'block';
            }
        }
    } catch (error) {
        if (loginAlert) {
            loginAlert.textContent = 'No se pudo conectar con el servidor. ¿Está corriendo node server.js?';
            loginAlert.style.display = 'block';
        }
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Ingresar al panel';
        }
    }
}
 
function handleLogout() {
    setAdminLoggedInState(false);
}
 

 
async function loadAdminProducts() {
    try {
        const response = await fetch(`${API_URL}/productos`);
        adminProducts = response.ok ? await response.json() : [];
    } catch (error) {
        adminProducts = [];
    }
    renderAdminMenuTable();
}
 
function renderAdminMenuTable() {
    const tbody = document.querySelector('#adminMenuTable tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
 
    if (adminProducts.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `<td colspan="5" class="empty-table-msg">No hay productos en el menú. Agrega uno arriba.</td>`;
        tbody.appendChild(row);
        return;
    }
 
    adminProducts.forEach(item => {
        const row = document.createElement('tr');
        row.dataset.productId = item.id;
        const oculto = item.disponible === false;
 
        row.innerHTML = `
            <td data-label="Sección"><span class="badge-category">${item.categoria}</span></td>
            <td data-label="Producto" class="td-editable-nombre">
                <strong class="prod-name">${item.nombre}</strong>
                ${item.descripcion ? `<p class="prod-desc">${item.descripcion}</p>` : ''}
                ${oculto ? '<span class="badge-category estado-entregado">Oculto</span>' : ''}
            </td>
            <td data-label="Precio" class="prod-price td-editable-precio">$${Number(item.precio).toLocaleString('es-AR')}</td>
            <td data-label="Acciones" class="td-action">
                <button class="btn btn-secondary-small" type="button" data-edit-id="${item.id}" title="Editar producto">
                    Editar
                </button>
                <button class="btn btn-secondary-small" type="button" data-toggle-id="${item.id}" title="Ocultar o mostrar producto">
                    ${oculto ? 'Mostrar' : 'Ocultar'}
                </button>
                <button class="btn btn-delete" type="button" data-delete-id="${item.id}" title="Eliminar producto definitivamente">
                    Eliminar
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
 
    tbody.querySelectorAll('[data-delete-id]').forEach(button => {
        button.addEventListener('click', () => {
            const item = adminProducts.find(p => p.id === button.dataset.deleteId);
            const confirmMsg = `¿Eliminar "${item ? item.nombre : 'este producto'}" definitivamente? Esta acción no se puede deshacer.`;
            if (confirm(confirmMsg)) {
                deleteAdminProduct(button.dataset.deleteId);
            }
        });
    });
 
    tbody.querySelectorAll('[data-toggle-id]').forEach(button => {
        button.addEventListener('click', () => {
            toggleDisponibleProducto(button.dataset.toggleId);
        });
    });
 
    tbody.querySelectorAll('[data-edit-id]').forEach(button => {
        button.addEventListener('click', () => {
            iniciarEdicionProducto(button.dataset.editId);
        });
    });
}
 
async function addAdminProduct(event) {
    if (event) event.preventDefault();
 
    const nameInput = document.getElementById('newProdName');
    const descInput = document.getElementById('newProdDesc');
    const priceInput = document.getElementById('newProdPrice');
    const sectionInput = document.getElementById('newProdSection');
    const alertBox = document.getElementById('adminAlert');
 
    const nombre = nameInput ? nameInput.value.trim() : '';
    const descripcion = descInput ? descInput.value.trim() : '';
    const precio = priceInput ? Number(priceInput.value) : 0;
    const categoria = sectionInput ? sectionInput.value : 'Almuerzo';
 
    if (!nombre || precio <= 0) {
        if (alertBox) {
            alertBox.className = 'admin-alert error';
            alertBox.textContent = 'Por favor completa el nombre y un precio válido mayor a 0.';
            alertBox.style.display = 'block';
        }
        return;
    }
 
    try {
        const response = await fetch(`${API_URL}/productos`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getToken()
            },
            body: JSON.stringify({ nombre, descripcion, precio, categoria })
        });
 
        const data = await response.json();
 
        if (!response.ok) {
            if (alertBox) {
                alertBox.className = 'admin-alert error';
                alertBox.textContent = data.error || 'No se pudo guardar el producto.';
                alertBox.style.display = 'block';
            }
            return;
        }
 
        await loadAdminProducts();
 
        if (nameInput) nameInput.value = '';
        if (descInput) descInput.value = '';
        if (priceInput) priceInput.value = '';
        if (sectionInput) sectionInput.value = 'Almuerzo';
 
        if (alertBox) {
            alertBox.className = 'admin-alert success';
            alertBox.textContent = `Producto "${nombre}" agregado correctamente al menú.`;
            alertBox.style.display = 'block';
            setTimeout(() => { alertBox.style.display = 'none'; }, 3000);
        }
    } catch (error) {
        if (alertBox) {
            alertBox.className = 'admin-alert error';
            alertBox.textContent = 'No se pudo conectar con el servidor.';
            alertBox.style.display = 'block';
        }
    }
}
 
async function deleteAdminProduct(productId) {
    try {
        await fetch(`${API_URL}/productos/${productId}`, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + getToken() }
        });
        await loadAdminProducts();
    } catch (error) {
        console.error('No se pudo eliminar el producto', error);
    }
}
 
async function actualizarProducto(productId, campos) {
    const response = await fetch(`${API_URL}/productos/${productId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + getToken()
        },
        body: JSON.stringify(campos)
    });
 
    if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || 'No se pudo actualizar el producto.');
    }
 
    await loadAdminProducts();
}
 
async function toggleDisponibleProducto(productId) {
    const item = adminProducts.find(p => p.id === productId);
    if (!item) return;
 
    const nuevoValor = item.disponible === false ? true : false;
 
    try {
        await actualizarProducto(productId, { disponible: nuevoValor });
    } catch (error) {
        alert(error.message);
    }
}
 
function iniciarEdicionProducto(productId) {
    const item = adminProducts.find(p => p.id === productId);
    if (!item) return;
 
    const nuevoNombre = prompt('Nombre del producto:', item.nombre);
    if (nuevoNombre === null) return; 
 
    const nuevoPrecioTexto = prompt('Precio del producto:', item.precio);
    if (nuevoPrecioTexto === null) return; 
 
    const nuevoPrecio = Number(nuevoPrecioTexto);
    if (!nuevoNombre.trim() || !nuevoPrecio || nuevoPrecio <= 0) {
        alert('El nombre no puede estar vacío y el precio tiene que ser un número mayor a 0.');
        return;
    }
 
    const nuevaDescripcion = prompt('Descripción (podés dejarla como está):', item.descripcion || '');
    if (nuevaDescripcion === null) return; 
 
    actualizarProducto(productId, {
        nombre: nuevoNombre.trim(),
        precio: nuevoPrecio,
        descripcion: nuevaDescripcion.trim()
    }).catch(error => alert(error.message));
}
 

 
document.addEventListener('DOMContentLoaded', () => {
    checkExistingSession();
 
    const loginForm = document.getElementById('adminLoginForm');
    if (loginForm) loginForm.addEventListener('submit', handleLogin);
 
    const logoutBtn = document.getElementById('adminLogoutBtn');
    if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);
 
    const addForm = document.getElementById('addProductForm');
    if (addForm) addForm.addEventListener('submit', addAdminProduct);
});
 