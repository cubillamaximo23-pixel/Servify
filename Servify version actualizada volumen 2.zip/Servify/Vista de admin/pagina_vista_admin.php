<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_admin.css">
    <title>Servify - Panel de Administrador</title>
</head>
<body>
    <div class="admin-shell">
        <header class="admin-topbar">
            <div class="brand-area">
                <span class="brand-sub">Panel de Control</span>
                <h1 class="brand-title">Servify Admin</h1>
            </div>

            <div class="topbar-actions">
                <a href="pagina_vista_pedidos.php" class="btn-link">Ver pedidos ↗</a>
                <a href="../pagina_vista_usuario.php" class="btn-link">Ver vista cliente ↗</a>
                <button id="adminLogoutBtn" class="btn btn-logout" type="button" style="display:none;">Cerrar sesión</button>
            </div>
        </header>

        <section class="login-wrapper" id="loginSection">
            <div class="admin-card login-card">
                <h2>Ingreso de Administrador</h2>
                <p class="login-sub">Accede para gestionar los productos y precios de la carta.</p>

                <div id="loginAlert" class="admin-alert error" style="display: none;"></div>

                <form class="admin-form" id="adminLoginForm">
                    <div class="form-group">
                        <label for="adminUsername">Usuario</label>
                        <input type="text" id="adminUsername" autocomplete="username" required>
                    </div>
                    <div class="form-group">
                        <label for="adminPassword">Contraseña</label>
                        <input type="password" id="adminPassword" placeholder="••••••••" autocomplete="current-password" required>
                    </div>
                    <button class="btn btn-primary" type="submit" id="loginSubmitBtn">Ingresar al panel</button>
                </form>
            </div>
        </section>

        <main class="admin-grid" id="dashboardSection" style="display:none;">
            <section class="admin-card">
                <div class="card-header">
                    <h2>Cargar nuevo producto</h2>
                    <p class="card-sub">Agrega un nuevo ítem a la carta del menú digital.</p>
                </div>

                <div id="adminAlert" class="admin-alert" style="display:none;"></div>

                <form id="addProductForm" class="admin-form">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="newProdName">Nombre del producto</label>
                            <input type="text" id="newProdName" placeholder="Ej: Pizza Cuatro Quesos" required>
                        </div>
                        <div class="form-group">
                            <label for="newProdPrice">Precio ($)</label>
                            <input type="number" id="newProdPrice" min="1" placeholder="Ej: 9500" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="newProdSection">Categoría / Sección</label>
                        <select id="newProdSection">
                            <option value="Desayuno">Desayuno</option>
                            <option value="Almuerzo">Almuerzo</option>
                            <option value="Merienda">Merienda</option>
                            <option value="Cena">Cena</option>
                            <option value="Bebidas">Bebidas</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="newProdDesc">Descripción de ingredientes / detalle</label>
                        <textarea id="newProdDesc" rows="2" placeholder="Ej: Salsa de tomate, mozzarella, parmesano, provolone y roquefort."></textarea>
                    </div>

                    <button class="btn btn-primary" type="submit">Guardar producto en el menú</button>
                </form>
            </section>

            <section class="admin-card">
                <div class="card-header">
                    <h2>Menú actual</h2>
                    <p class="card-sub">Listado de productos cargados actualmente en el sistema.</p>
                </div>

                <div class="table-container">
                    <table class="admin-table" id="adminMenuTable">
                        <thead>
                            <tr>
                                <th>Sección</th>
                                <th>Producto</th>
                                <th>Precio</th>
                                <th class="th-action">Eliminar</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>

    <script src="backend_vista_admin.js"></script>
</body>
</html>