<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_admin.css">
    <title>Servify - Pedidos</title>
</head>
<body>
    <div class="admin-shell">
        <header class="admin-topbar">
            <div class="brand-area">
                <span class="brand-sub">Panel de Cocina</span>
                <h1 class="brand-title">Pedidos</h1>
            </div>

            <div class="topbar-actions">
                <a href="pagina_vista_admin.php" class="btn-link">Ver productos ↗</a>
                <a href="../pagina_vista_usuario.php" class="btn-link">Ver vista cliente ↗</a>
                <button id="ordersLogoutBtn" class="btn btn-logout" type="button">Cerrar sesión</button>
            </div>
        </header>

        <section id="ordersLoginNotice" class="admin-card" style="display:none;">
            <h2>Necesitás iniciar sesión</h2>
            <p class="card-sub">Para ver los pedidos primero tenés que loguearte en el panel de administrador.</p>
            <a href="pagina_vista_admin.php" class="btn btn-primary" style="display:inline-block; text-decoration:none; width:fit-content;">Ir a iniciar sesión</a>
        </section>

        <main class="admin-grid" id="ordersSection">
            <section class="admin-card">
                <div class="card-header">
                    <h2>Pedidos activos</h2>
                    <p class="card-sub">Se actualiza cada vez que recargás la página. Tocá el botón de cada pedido para avanzarlo al siguiente estado.</p>
                </div>

                <div class="filter-tabs" id="filterTabs">
                    <button type="button" class="filter-tab active" data-filter="activos">Activos</button>
                    <button type="button" class="filter-tab" data-filter="todos">Todos</button>
                </div>

                <div id="ordersAlert" class="admin-alert" style="display:none;"></div>

                <div id="ordersList" class="orders-list"></div>
            </section>
        </main>
    </div>

    <script src="backend_vista_pedidos.js"></script>
</body>
</html>
