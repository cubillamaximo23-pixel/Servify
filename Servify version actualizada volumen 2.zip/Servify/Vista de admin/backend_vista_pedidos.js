// Servify — Vista de pedidos (cocina)
// Usa el mismo token de sesión que el panel de administrador.

const API_URL = 'http://localhost:3000/api';

const ESTADOS_ORDEN = ['pendiente', 'en_preparacion', 'listo', 'entregado'];

const ESTADO_LABEL = {
    pendiente:      'Pendiente',
    en_preparacion: 'En preparación',
    listo:          'Listo',
    entregado:      'Entregado'
};

const SIGUIENTE_ACCION = {
    pendiente:      'Marcar en preparación',
    en_preparacion: 'Marcar listo',
    listo:          'Marcar entregado'
};

let currentFilter = 'activos';
let pedidos = [];

function getToken() {
    return sessionStorage.getItem('servify_admin_token');
}

function formatPrice(amount) {
    return `$${Number(amount || 0).toLocaleString('es-AR')}`;
}

function formatFecha(iso) {
    const fecha = new Date(iso);
    return fecha.toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function siguienteEstado(estadoActual) {
    const index = ESTADOS_ORDEN.indexOf(estadoActual);
    if (index === -1 || index === ESTADOS_ORDEN.length - 1) return null;
    return ESTADOS_ORDEN[index + 1];
}

async function cargarPedidos() {
    const alertBox = document.getElementById('ordersAlert');
    const token = getToken();

    if (!token) {
        mostrarNecesitaLogin();
        return;
    }

    try {
        const response = await fetch(`${API_URL}/pedidos`, {
            headers: { 'Authorization': 'Bearer ' + token }
        });

        if (response.status === 401) {
            mostrarNecesitaLogin();
            return;
        }

        if (!response.ok) {
            throw new Error('No se pudieron cargar los pedidos.');
        }

        pedidos = await response.json();
        if (alertBox) alertBox.style.display = 'none';
        renderPedidos();
    } catch (error) {
        if (alertBox) {
            alertBox.className = 'admin-alert error';
            alertBox.textContent = 'No se pudo conectar con el servidor. ¿Está corriendo node server.js?';
            alertBox.style.display = 'block';
        }
    }
}

function mostrarNecesitaLogin() {
    const loginNotice = document.getElementById('ordersLoginNotice');
    const ordersSection = document.getElementById('ordersSection');
    if (loginNotice) loginNotice.style.display = 'flex';
    if (ordersSection) ordersSection.style.display = 'none';
}

function renderPedidos() {
    const list = document.getElementById('ordersList');
    if (!list) return;

    const visibles = currentFilter === 'activos'
        ? pedidos.filter(p => p.estado !== 'entregado')
        : pedidos;

    list.innerHTML = '';

    if (visibles.length === 0) {
        list.innerHTML = `<p class="empty-table-msg">No hay pedidos ${currentFilter === 'activos' ? 'activos' : ''} por ahora.</p>`;
        return;
    }

    visibles.forEach(pedido => {
        const items = Array.isArray(pedido.items) ? pedido.items : [];
        const itemsHtml = items.map(item => {
            const ingredientes = Array.isArray(item.ingredientes) && item.ingredientes.length > 0
                ? `<span class="order-item-extras">Extras: ${item.ingredientes.join(', ')}</span>`
                : '';
            return `
                <div class="order-item-row">
                    <span>${item.cantidad}x ${item.nombre}</span>
                    ${ingredientes}
                </div>`;
        }).join('');

        const siguiente = siguienteEstado(pedido.estado);
        const accionBtn = siguiente
            ? `<button type="button" class="btn btn-primary" data-order-id="${pedido.id}" data-next-estado="${siguiente}">
                   ${SIGUIENTE_ACCION[pedido.estado]}
               </button>`
            : `<span class="badge-category">Ciclo completo</span>`;

        const card = document.createElement('article');
        card.className = 'admin-card order-card';
        card.innerHTML = `
            <div class="order-card-header">
                <div>
                    <strong class="prod-name">${pedido.mesa}</strong>
                    <span class="card-sub">${formatFecha(pedido.creado_at)}${pedido.retiro_mostrador ? ' · Retira en mostrador' : ''}</span>
                </div>
                <span class="badge-category estado-${pedido.estado}">${ESTADO_LABEL[pedido.estado] || pedido.estado}</span>
            </div>
            <div class="order-items">${itemsHtml}</div>
            <div class="order-card-footer">
                <strong class="prod-price">${formatPrice(pedido.total)}</strong>
                ${accionBtn}
            </div>
        `;
        list.appendChild(card);
    });

    list.querySelectorAll('[data-order-id]').forEach(btn => {
        btn.addEventListener('click', () => {
            cambiarEstado(btn.dataset.orderId, btn.dataset.nextEstado);
        });
    });
}

async function cambiarEstado(pedidoId, nuevoEstado) {
    try {
        const response = await fetch(`${API_URL}/pedidos/${pedidoId}/estado`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getToken()
            },
            body: JSON.stringify({ estado: nuevoEstado })
        });

        if (!response.ok) throw new Error('No se pudo actualizar el estado.');

        await cargarPedidos();
    } catch (error) {
        const alertBox = document.getElementById('ordersAlert');
        if (alertBox) {
            alertBox.className = 'admin-alert error';
            alertBox.textContent = 'No se pudo actualizar el pedido. Probá de nuevo.';
            alertBox.style.display = 'block';
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    cargarPedidos();

    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            currentFilter = tab.dataset.filter;
            renderPedidos();
        });
    });

    const logoutBtn = document.getElementById('ordersLogoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            sessionStorage.removeItem('servify_admin_token');
            sessionStorage.removeItem('servify_admin_logged');
            window.location.href = 'pagina_vista_admin.php';
        });
    }
});
