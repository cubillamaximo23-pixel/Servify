<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#2C1E2D">
    <link rel="stylesheet" href="style.css">
    <title>Servify - Menú Digital</title>
</head>
<body>
    <div class="app-layout">
        <header class="app-header">
            <div class="brand-area">
                <span class="brand-sub">Servicio rápido & mesa</span>
                <h1 class="brand-name">Servify</h1>
            </div>

            <div class="status-indicators">
                <div class="status-chip">
                    <span class="chip-label">Tu posición</span>
                    <strong class="chip-value" id="queueBadge">0 en fila</strong>
                </div>
                <div class="status-chip highlight">
                    <span class="chip-label">Identificador</span>
                    <strong class="chip-value" id="orderTicket">Sin pedido activo</strong>
                </div>
            </div>
        </header>

        <main class="main-content">
            <section class="menu-column">
                <div class="section-topbar">
                    <div>
                        <h2 class="section-title">Carta y Menú</h2>
                        <p class="section-subtitle">Toca cada categoría para desplegar u ocultar sus opciones.</p>
                    </div>

                    <div class="table-selector-wrapper">
                        <label for="tableSelector">Mesa:</label>
                        <select id="tableSelector" aria-label="Seleccionar mesa">
                            <option value="Mesa 1">Mesa 1</option>
                            <option value="Mesa 2">Mesa 2</option>
                            <option value="Mesa 3">Mesa 3</option>
                            <option value="Mesa 4">Mesa 4</option>
                            <option value="Mesa 5">Mesa 5</option>
                            <option value="Mesa 6">Mesa 6</option>
                        </select>
                    </div>
                </div>

                <div id="menuSections" class="menu-categories-wrapper"></div>
            </section>

            <aside class="cart-aside">
                <div class="cart-box">
                    <div class="cart-box-header">
                        <h3 class="cart-title">Pedido de la Mesa</h3>
                        <span class="cart-hint">Acumulativo</span>
                    </div>

                    <div class="pickup-toggle-box">
                        <label class="custom-checkbox" for="selfPickup">
                            <input type="checkbox" id="selfPickup">
                            <span class="checkbox-indicator"></span>
                            <span class="checkbox-text">Buscarlo yo mismo (Retiro en mostrador)</span>
                        </label>
                    </div>

                    <div id="pickupAlert" class="pickup-alert-container hidden"></div>

                    <div id="cartContent" class="cart-items-container"></div>

                    <div id="cartSummary" class="cart-summary-box"></div>
                </div>
            </aside>
        </main>

        <div class="mobile-cart-bar" id="mobileCartBar">
            <div class="mobile-cart-info">
                <span id="mobileCartCount">0 items</span>
                <strong id="mobileCartTotal">$0</strong>
            </div>
            <button type="button" class="btn-mobile-view" id="mobileViewCartBtn">
                Ver comanda ↗
            </button>
        </div>
    </div>

    <script src="backend_vista_usuario.js"></script>
</body>
</html>