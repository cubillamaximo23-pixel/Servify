// fiveserver.config.js
module.exports = {
  php: "C:\\xampp\\php\\php.exe", // Windows (XAMPP)
  open: "index.php",
  highlight: true,
  injectBody: true
};
