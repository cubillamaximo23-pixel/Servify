// ============================================================
//  SERVIFY — Servidor Node.js + Express + Supabase
//  Archivo: server.js
//  Instrucciones de uso al final del archivo
// ============================================================

const express    = require('express');
const cors       = require('cors');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middlewares ──────────────────────────────────────────────
app.use(cors());           // permite que el PHP/HTML consuma la API
app.use(express.json());   // parsea el body en JSON

// ── Cliente Supabase ─────────────────────────────────────────
const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_KEY
);

// ============================================================
//  RUTAS — MENÚ / PRODUCTOS
// ============================================================

// GET /api/menu
// Devuelve todos los productos agrupados por categoría
// Reemplaza el defaultMenuData hardcodeado en backend_vista_usuario.js
app.get('/api/menu', async (req, res) => {
    const { data, error } = await supabase
        .from('productos')
        .select('*')
        .eq('disponible', true)
        .order('categoria', { ascending: true });

    if (error) {
        console.error('[GET /api/menu]', error.message);
        return res.status(500).json({ error: error.message });
    }

    // Agrupar por categoría para que el frontend lo reciba igual
    // que el defaultMenuData original
    const secciones = ['Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Bebidas'];
    const menuAgrupado = secciones.map(cat => ({
        title: cat,
        items: data.filter(p => p.categoria === cat)
    })).filter(s => s.items.length > 0);

    res.json(menuAgrupado);
});

// GET /api/productos
// Devuelve la lista plana de productos (usada por el panel admin)
app.get('/api/productos', async (req, res) => {
    const { data, error } = await supabase
        .from('productos')
        .select('*')
        .order('categoria', { ascending: true });

    if (error) {
        console.error('[GET /api/productos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});

// POST /api/productos
// Crea un producto nuevo (panel admin)
app.post('/api/productos', async (req, res) => {
    const { nombre, descripcion, precio, categoria, disponible } = req.body;

    // Validación básica
    if (!nombre || !precio || !categoria) {
        return res.status(400).json({ error: 'nombre, precio y categoria son obligatorios.' });
    }

    const secciones = ['Desayuno', 'Almuerzo', 'Merienda', 'Cena', 'Bebidas'];
    if (!secciones.includes(categoria)) {
        return res.status(400).json({ error: `Categoría inválida. Usar: ${secciones.join(', ')}` });
    }

    const { data, error } = await supabase
        .from('productos')
        .insert([{
            nombre,
            descripcion: descripcion || '',
            precio: Number(precio),
            categoria,
            disponible: disponible !== undefined ? disponible : true
        }])
        .select()
        .single();

    if (error) {
        console.error('[POST /api/productos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data);
});

// PUT /api/productos/:id
// Editar un producto existente
app.put('/api/productos/:id', async (req, res) => {
    const { id } = req.params;
    const campos = req.body;

    const { data, error } = await supabase
        .from('productos')
        .update(campos)
        .eq('id', id)
        .select()
        .single();

    if (error) {
        console.error('[PUT /api/productos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});

// DELETE /api/productos/:id
// Eliminar producto
app.delete('/api/productos/:id', async (req, res) => {
    const { id } = req.params;

    const { error } = await supabase
        .from('productos')
        .delete()
        .eq('id', id);

    if (error) {
        console.error('[DELETE /api/productos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json({ mensaje: 'Producto eliminado correctamente.' });
});

// ============================================================
//  RUTAS — PEDIDOS
// ============================================================

// POST /api/pedidos
// El cliente finaliza su pedido — equivale al botón "Finalizar pedido"
app.post('/api/pedidos', async (req, res) => {
    const { mesa, items, retiro_mostrador } = req.body;

    // Validación
    if (!mesa || !items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Pedido incompleto. Se requiere mesa e items.' });
    }

    // Calcular total del lado del servidor (nunca confiar solo en el cliente)
    const total = items.reduce((sum, item) => {
        return sum + (Number(item.precio) * Number(item.cantidad));
    }, 0);

    const { data, error } = await supabase
        .from('pedidos')
        .insert([{
            mesa,
            items,          // jsonb: guarda el array completo del carrito
            total,
            retiro_mostrador: retiro_mostrador || false,
            estado: 'pendiente'
        }])
        .select()
        .single();

    if (error) {
        console.error('[POST /api/pedidos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json({
        mensaje: '¡Pedido recibido!',
        pedido_id: data.id,
        numero_turno: data.numero_turno || data.id.slice(0, 6).toUpperCase(),
        total: data.total
    });
});

// GET /api/pedidos
// Panel admin: lista todos los pedidos pendientes del día
app.get('/api/pedidos', async (req, res) => {
    const { estado } = req.query; // ?estado=pendiente

    let query = supabase
        .from('pedidos')
        .select('*')
        .order('creado_at', { ascending: false });

    if (estado) {
        query = query.eq('estado', estado);
    }

    const { data, error } = await query;

    if (error) {
        console.error('[GET /api/pedidos]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});

// PATCH /api/pedidos/:id/estado
// El admin cambia el estado de un pedido (pendiente → en_preparacion → listo)
app.patch('/api/pedidos/:id/estado', async (req, res) => {
    const { id }     = req.params;
    const { estado } = req.body;

    const estadosValidos = ['pendiente', 'en_preparacion', 'listo', 'entregado'];
    if (!estadosValidos.includes(estado)) {
        return res.status(400).json({ error: `Estado inválido. Opciones: ${estadosValidos.join(', ')}` });
    }

    const { data, error } = await supabase
        .from('pedidos')
        .update({ estado })
        .eq('id', id)
        .select()
        .single();

    if (error) {
        console.error('[PATCH /api/pedidos/estado]', error.message);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
});

// ============================================================
//  RUTAS — ADMIN
// ============================================================
const bcrypt = require('bcryptjs');

app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ success: false, error: 'Usuario y contraseña son requeridos' });
    }

    try {
        // Buscar el usuario en Supabase
        const { data, error } = await supabase
            .from('admin_users')
            .select('*')
            .eq('username', username)
            .single();

        if (error || !data) {
            return res.status(401).json({ success: false, error: 'Usuario o contraseña incorrectos.' });
        }

        // Verificar la contraseña hasheada
        const match = await bcrypt.compare(password, data.password_hash);
        
        if (!match) {
            return res.status(401).json({ success: false, error: 'Usuario o contraseña incorrectos.' });
        }

        // Login exitoso
        res.json({ success: true, message: 'Login exitoso' });
    } catch (err) {
        console.error('[POST /api/admin/login]', err.message);
        res.status(500).json({ success: false, error: 'Error interno del servidor.' });
    }
});

// ============================================================
//  RUTA DE ESTADO — verificar que el servidor está vivo
// ============================================================
app.get('/api/status', async (req, res) => {
    // Prueba rápida de conexión con Supabase
    const { error } = await supabase.from('productos').select('id').limit(1);
    res.json({
        servidor: 'activo',
        supabase: error ? 'error: ' + error.message : 'conectado',
        timestamp: new Date().toISOString()
    });
});

// ============================================================
//  INICIO DEL SERVIDOR
// ============================================================
app.listen(PORT, () => {
    console.log(`\n✅ Servidor Servify corriendo en http://localhost:${PORT}`);
    console.log(`   → Verificar estado:  http://localhost:${PORT}/api/status`);
    console.log(`   → Ver menú:          http://localhost:${PORT}/api/menu`);
    console.log(`   → Ver pedidos:       http://localhost:${PORT}/api/pedidos\n`);
});

// ============================================================
//
//  INSTRUCCIONES DE INSTALACIÓN Y USO
//  ══════════════════════════════════
//
//  1. Instalar dependencias (una sola vez):
//     npm install
//
//  2. Completar el archivo .env con tus credenciales de Supabase:
//     SUPABASE_URL=https://xxxx.supabase.co
//     SUPABASE_KEY=eyJhbGci...
//     PORT=3000
//
//  3. En Supabase, crear estas dos tablas desde el SQL Editor:
//
//     -- TABLA PRODUCTOS
//     create table productos (
//       id          uuid primary key default gen_random_uuid(),
//       nombre      text not null,
//       descripcion text default '',
//       precio      numeric not null,
//       categoria   text not null,
//       disponible  boolean default true,
//       creado_at   timestamp default now()
//     );
//
//     -- TABLA PEDIDOS
//     create table pedidos (
//       id               uuid primary key default gen_random_uuid(),
//       mesa             text not null,
//       items            jsonb not null,
//       total            numeric not null default 0,
//       retiro_mostrador boolean default false,
//       estado           text default 'pendiente',
//       creado_at        timestamp default now()
//     );
//
//  4. Iniciar el servidor:
//     node server.js
//
//  5. En backend_vista_usuario.js reemplazar getFullMenu() por
//     una llamada fetch a http://localhost:3000/api/menu
//     Ver el archivo: backend_vista_usuario.NUEVO.js
//
// ============================================================
