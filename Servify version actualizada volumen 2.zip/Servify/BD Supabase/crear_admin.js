const bcrypt = require('bcryptjs');
const readline = require('readline');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_KEY
);

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

console.log("\n=============================================");
console.log("   CREAR USUARIO ADMINISTRADOR EN SUPABASE   ");
console.log("=============================================\n");

rl.question("👉 Ingresá el nombre de usuario deseado: ", (username) => {
    rl.question("👉 Ingresá la contraseña (mínimo 6 caracteres): ", async (password) => {
        
        if (password.length < 6) {
            console.error("\n❌ Error: La contraseña debe tener al menos 6 caracteres.");
            rl.close();
            return;
        }

        try {
            console.log("\n⏳ Generando hash de contraseña...");
            const salt = await bcrypt.genSalt(10);
            const hash = await bcrypt.hash(password, salt);

            console.log("⏳ Guardando usuario en Supabase...");
            const { data, error } = await supabase
                .from('admin_users')
                .insert([{ username: username, password_hash: hash }])
                .select()
                .single();

            if (error) {
                if (error.code === '23505') { // constraint violation (unique)
                    console.error(`\n❌ Error: El usuario "${username}" ya existe en la base de datos.`);
                } else {
                    console.error("\n❌ Error de Supabase:", error.message);
                }
            } else {
                console.log(`\n✅ ¡Usuario "${username}" creado exitosamente!`);
                console.log("Ya podés iniciar sesión en el panel de administrador.");
            }
        } catch (err) {
            console.error("\n❌ Error inesperado:", err);
        } finally {
            rl.close();
        }
    });
});
